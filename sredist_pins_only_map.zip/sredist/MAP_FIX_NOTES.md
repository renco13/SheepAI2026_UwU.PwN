# Map visibility fix

This patch keeps the project on MapLibre. Do not install `leaflet` or `react-leaflet` for this app.

What changed:

- Replaced the external MapLibre demo style URL with an inline OpenStreetMap raster style.
- Fixed the React effect lifecycle bug where the map was removed after `/api/map` data loaded.
- Added `map.resize()` hardening with `ResizeObserver` and delayed resize calls.
- Added fallback Split demo neighborhoods/reports when `/api/map` fails or returns invalid data.
- Added small visible status/debug overlays so the map never silently fails.
- Removed the symbol label layer dependency to avoid glyph/font loading problems during a hackathon demo.

Run:

```bash
npm install
npm run dev
```

If you previously attempted to install Leaflet, remove accidental installs with:

```bash
npm uninstall leaflet react-leaflet @types/leaflet
```
