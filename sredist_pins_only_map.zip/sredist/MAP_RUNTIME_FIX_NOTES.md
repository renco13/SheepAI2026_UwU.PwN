# Runtime fix: MapLibre `Map` name collision

Problem seen in Next.js overlay:

```text
Error: Invalid type: 'container' must be a String or HTMLElement.
src/components/map/split-map.tsx @ withReportCounts
const counts = new Map<string, number>();
```

Cause:

`split-map.tsx` imported `Map` from `maplibre-gl`, which shadowed JavaScript's native `Map` collection. Therefore this line:

```ts
const counts = new Map<string, number>();
```

created a MapLibre map instance instead of a native key/value map. MapLibre then expected a `container` option and crashed.

Fix:

- Stop importing runtime `Map` from `maplibre-gl`.
- Import the MapLibre map only as a type alias: `MapLibreMap`.
- Use `new globalThis.Map<string, number>()` for report count aggregation.

