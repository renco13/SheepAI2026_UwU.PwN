import { registerAction } from "@/features/auth/actions";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";

const errors: Record<string, string> = {
  invalid: "Provjeri podatke. Lozinka mora imati barem 8 znakova.",
  exists: "Račun s tim emailom već postoji.",
  oib: "Organizacija mora unijeti valjani OIB od 11 znamenki."
};

export default function RegisterPage({ searchParams }: { searchParams: { error?: string } }) {
  return (
    <div className="mx-auto max-w-lg pb-24">
      <Card>
        <CardContent className="p-6">
          <h1 className="text-2xl font-black">Registracija</h1>
          <p className="mt-1 text-sm text-muted-foreground">Građani odmah mogu koristiti sustav. Udruge čekaju admin odobrenje.</p>
          {searchParams.error && <p className="mt-4 rounded-xl bg-destructive/10 p-3 text-sm text-destructive">{errors[searchParams.error] ?? errors.invalid}</p>}
          <form action={registerAction} className="mt-6 space-y-4">
            <div className="space-y-2"><Label htmlFor="displayName">Ime / naziv</Label><Input id="displayName" name="displayName" required /></div>
            <div className="space-y-2"><Label htmlFor="email">Email</Label><Input id="email" name="email" type="email" required /></div>
            <div className="space-y-2"><Label htmlFor="password">Lozinka</Label><Input id="password" name="password" type="password" minLength={8} required /></div>
            <div className="space-y-2">
              <Label htmlFor="accountType">Tip računa</Label>
              <Select id="accountType" name="accountType" defaultValue="citizen">
                <option value="citizen">Građanin</option>
                <option value="organization">Udruga / organizacija</option>
              </Select>
            </div>
            <div className="space-y-2"><Label htmlFor="organizationOib">OIB organizacije</Label><Input id="organizationOib" name="organizationOib" inputMode="numeric" placeholder="Samo za udruge" /></div>
            <Button type="submit" className="w-full">Kreiraj račun</Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
