import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="mx-auto max-w-lg rounded-3xl border bg-card p-8 text-center shadow-sm">
      <h1 className="text-3xl font-black">Stranica nije pronađena</h1>
      <p className="mt-2 text-muted-foreground">Traženi sadržaj ne postoji ili je uklonjen.</p>
      <Button asChild className="mt-6"><Link href="/map">Natrag na kartu</Link></Button>
    </div>
  );
}
