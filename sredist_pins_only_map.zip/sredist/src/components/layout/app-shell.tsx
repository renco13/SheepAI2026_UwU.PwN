import Link from "next/link";
import { Leaf, Map, Shield, UserRound, CalendarDays } from "lucide-react";
import { CurrentUser } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { logoutAction } from "@/features/auth/actions";

export function AppShell({ children, user }: { children: React.ReactNode; user: CurrentUser | null }) {
  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-40 border-b bg-background/85 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3">
          <Link href="/" className="flex items-center gap-2 font-black tracking-tight">
            <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow">
              <Leaf className="h-5 w-5" />
            </span>
            <span className="text-xl">SrediST</span>
          </Link>

          <nav className="hidden items-center gap-2 md:flex">
            <Button variant="ghost" asChild><Link href="/map"><Map className="h-4 w-4" /> Karta</Link></Button>
            <Button variant="ghost" asChild><Link href="/events"><CalendarDays className="h-4 w-4" /> Akcije</Link></Button>
            {user?.role === "admin" && <Button variant="ghost" asChild><Link href="/admin"><Shield className="h-4 w-4" /> Admin</Link></Button>}
            {user ? (
              <>
                <Button variant="outline" asChild><Link href="/dashboard"><UserRound className="h-4 w-4" /> {user.displayName}</Link></Button>
                <form action={logoutAction}><Button variant="secondary" type="submit">Odjava</Button></form>
              </>
            ) : (
              <>
                <Button variant="ghost" asChild><Link href="/login">Prijava</Link></Button>
                <Button asChild><Link href="/register">Registracija</Link></Button>
              </>
            )}
          </nav>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-6 md:py-8">{children}</main>

      <nav className="fixed bottom-0 left-0 right-0 z-50 border-t bg-background/95 backdrop-blur md:hidden">
        <div className="grid grid-cols-4 text-xs">
          <Link href="/map" className="flex flex-col items-center gap-1 py-3"><Map className="h-5 w-5" /> Karta</Link>
          <Link href="/events" className="flex flex-col items-center gap-1 py-3"><CalendarDays className="h-5 w-5" /> Akcije</Link>
          <Link href="/dashboard" className="flex flex-col items-center gap-1 py-3"><UserRound className="h-5 w-5" /> Profil</Link>
          <Link href={user?.role === "admin" ? "/admin" : "/login"} className="flex flex-col items-center gap-1 py-3"><Shield className="h-5 w-5" /> Admin</Link>
        </div>
      </nav>
    </div>
  );
}
