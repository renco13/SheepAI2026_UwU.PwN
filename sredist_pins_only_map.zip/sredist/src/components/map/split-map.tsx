"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import maplibregl, { GeoJSONSource, StyleSpecification } from "maplibre-gl";
import type { Map as MapLibreMap } from "maplibre-gl";
import type { FeatureCollection, Point } from "geojson";
import { REPORT_CATEGORIES, SPLIT_CENTER } from "@/lib/constants";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

type MapReport = {
  id: string;
  title: string;
  category: keyof typeof REPORT_CATEGORIES;
  status: string;
  latitude: number;
  longitude: number;
  voteScore: number;
  minPeopleNeeded: number;
  neighborhoodName: string;
  imageUrl: string | null;
};

type ReportProperties = {
  id: string;
  title: string;
  voteScore: number;
  category: keyof typeof REPORT_CATEGORIES;
};

const rasterMapStyle: StyleSpecification = {
  version: 8,
  sources: {
    osm: {
      type: "raster",
      tiles: ["https://tile.openstreetmap.org/{z}/{x}/{y}.png"],
      tileSize: 256,
      attribution: "© OpenStreetMap contributors"
    }
  },
  layers: [
    {
      id: "osm-raster-tiles",
      type: "raster",
      source: "osm",
      minzoom: 0,
      maxzoom: 19,
      paint: { "raster-saturation": -0.18, "raster-contrast": 0.04 }
    }
  ]
};

const fallbackReports: MapReport[] = [
  {
    id: "fallback-riva",
    title: "Demo marker: Riva / Get",
    category: "other",
    status: "open",
    latitude: 43.5081,
    longitude: 16.4392,
    voteScore: 3,
    minPeopleNeeded: 5,
    neighborhoodName: "Get",
    imageUrl: null
  },
  {
    id: "fallback-bacvice",
    title: "Demo marker: Bačvice",
    category: "beach",
    status: "open",
    latitude: 43.5023,
    longitude: 16.449,
    voteScore: 6,
    minPeopleNeeded: 7,
    neighborhoodName: "Bačvice",
    imageUrl: null
  },
  {
    id: "fallback-znjan",
    title: "Demo marker: Žnjan",
    category: "trash",
    status: "open",
    latitude: 43.4989,
    longitude: 16.4916,
    voteScore: 9,
    minPeopleNeeded: 10,
    neighborhoodName: "Žnjan",
    imageUrl: null
  },
  {
    id: "fallback-mertojak",
    title: "Demo marker: Mertojak",
    category: "green_area",
    status: "open",
    latitude: 43.5034,
    longitude: 16.4769,
    voteScore: 5,
    minPeopleNeeded: 8,
    neighborhoodName: "Mertojak",
    imageUrl: null
  }
];

function isValidCoordinate(latitude: number, longitude: number) {
  return (
    Number.isFinite(latitude) &&
    Number.isFinite(longitude) &&
    latitude >= -90 &&
    latitude <= 90 &&
    longitude >= -180 &&
    longitude <= 180
  );
}

function normalizeReports(payload: unknown): MapReport[] | null {
  if (!payload || typeof payload !== "object") return null;

  const maybePayload = payload as Partial<{ reports: Partial<MapReport>[] }>;
  const reports = Array.isArray(maybePayload.reports) ? maybePayload.reports : [];

  const validReports = reports
    .map((report) => ({
      ...report,
      id: String(report.id ?? ""),
      title: String(report.title ?? ""),
      category: report.category as keyof typeof REPORT_CATEGORIES,
      status: String(report.status ?? "open"),
      latitude: Number(report.latitude),
      longitude: Number(report.longitude),
      voteScore: Number(report.voteScore ?? 0),
      minPeopleNeeded: Number(report.minPeopleNeeded ?? 5),
      neighborhoodName: String(report.neighborhoodName ?? "Nepoznato"),
      imageUrl: report.imageUrl ?? null
    }))
    .filter((report): report is MapReport => {
      return Boolean(
        report.id &&
        report.title &&
        report.category &&
        isValidCoordinate(report.latitude, report.longitude)
      );
    });

  return validReports.length > 0 ? validReports : null;
}

export function SplitMap({ onPickLocation }: { onPickLocation?: (lat: number, lng: number) => void }) {
  const mapRef = useRef<MapLibreMap | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const reportsRef = useRef<MapReport[]>(fallbackReports);
  const pickLocationRef = useRef<typeof onPickLocation>(onPickLocation);

  const [reports, setReports] = useState<MapReport[]>(fallbackReports);
  const [selectedReport, setSelectedReport] = useState<MapReport | null>(null);
  const [picked, setPicked] = useState<{ lat: number; lng: number } | null>(null);
  const [mapReady, setMapReady] = useState(false);
  const [dataStatus, setDataStatus] = useState<"loading" | "live" | "fallback">("loading");
  const [mapError, setMapError] = useState<string | null>(null);

  useEffect(() => {
    reportsRef.current = reports;
  }, [reports]);

  useEffect(() => {
    pickLocationRef.current = onPickLocation;
  }, [onPickLocation]);

  useEffect(() => {
    let cancelled = false;

    async function loadMapData() {
      try {
        const response = await fetch("/api/map", { cache: "no-store" });
        if (!response.ok) throw new Error(`API /api/map returned ${response.status}`);

        const payload = await response.json();
        const normalizedReports = normalizeReports(payload);

        if (!cancelled && normalizedReports) {
          setReports(normalizedReports);
          setDataStatus("live");
          return;
        }

        if (!cancelled) {
          setReports(fallbackReports);
          setDataStatus("fallback");
        }
      } catch (error) {
        console.error("Map data loading failed", error);
        if (!cancelled) {
          setReports(fallbackReports);
          setDataStatus("fallback");
          setMapError(error instanceof Error ? error.message : "Neuspjelo učitavanje map podataka.");
        }
      }
    }

    loadMapData();

    return () => {
      cancelled = true;
    };
  }, []);

  const reportsFeatureCollection = useMemo<FeatureCollection<Point, ReportProperties>>(() => {
    return {
      type: "FeatureCollection",
      features: reports.map((report) => ({
        type: "Feature",
        properties: {
          id: report.id,
          title: report.title,
          voteScore: report.voteScore,
          category: report.category
        },
        geometry: { type: "Point", coordinates: [report.longitude, report.latitude] }
      }))
    };
  }, [reports]);

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const map = new maplibregl.Map({
      container: containerRef.current,
      style: rasterMapStyle,
      center: [SPLIT_CENTER.lng, SPLIT_CENTER.lat],
      zoom: 12.1,
      minZoom: 10,
      maxZoom: 18,
      pitch: 0,
      attributionControl: true
    });

    map.addControl(new maplibregl.NavigationControl({ visualizePitch: true }), "top-right");
    mapRef.current = map;

    const resizeMap = () => map.resize();
    const resizeObserver = new ResizeObserver(resizeMap);
    resizeObserver.observe(containerRef.current);

    const resizeTimers = [100, 350, 800].map((delay) => window.setTimeout(resizeMap, delay));

    map.on("load", () => {
      setMapReady(true);
      resizeMap();
    });

    map.on("error", (event) => {
      console.error("MapLibre error", event.error);
      setMapError(event.error?.message ?? "Greška pri učitavanju karte.");
    });

    map.on("mousemove", (event) => {
      const features = map.getLayer("report-points") ? map.queryRenderedFeatures(event.point, { layers: ["report-points"] }) : [];
      map.getCanvas().style.cursor = features.length > 0 ? "pointer" : "";
    });

    map.on("mouseleave", () => {
      map.getCanvas().style.cursor = "";
    });

    map.on("click", (event) => {
      if (map.getLayer("report-points")) {
        const features = map.queryRenderedFeatures(event.point, { layers: ["report-points"] });
        if (features.length > 0) {
          const reportId = features[0].properties?.id;
          const report = reportsRef.current.find((item) => item.id === reportId);
          if (report) setSelectedReport(report);
          return;
        }
      }

      const next = { lat: Number(event.lngLat.lat.toFixed(7)), lng: Number(event.lngLat.lng.toFixed(7)) };
      setPicked(next);
      pickLocationRef.current?.(next.lat, next.lng);
    });

    return () => {
      resizeTimers.forEach((timer) => window.clearTimeout(timer));
      resizeObserver.disconnect();
      map.remove();
      mapRef.current = null;
    };
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapReady) return;

    if (!map.getSource("reports")) {
      map.addSource("reports", { type: "geojson", data: reportsFeatureCollection });
      map.addLayer({
        id: "report-point-halo",
        type: "circle",
        source: "reports",
        minzoom: 10,
        paint: {
          "circle-radius": ["interpolate", ["linear"], ["get", "voteScore"], -3, 10, 0, 12, 10, 18],
          "circle-color": "#f2b753",
          "circle-opacity": 0.2,
          "circle-stroke-width": 0
        }
      });
      map.addLayer({
        id: "report-points",
        type: "circle",
        source: "reports",
        minzoom: 10,
        paint: {
          "circle-radius": ["interpolate", ["linear"], ["get", "voteScore"], -3, 6, 0, 8, 10, 13],
          "circle-color": "#f2b753",
          "circle-stroke-color": "#14532d",
          "circle-stroke-width": 2,
          "circle-opacity": 0.96
        }
      });
    } else {
      (map.getSource("reports") as GeoJSONSource).setData(reportsFeatureCollection);
    }

    map.resize();
  }, [mapReady, reportsFeatureCollection]);

  const useMyLocation = useCallback(() => {
    if (!navigator.geolocation) {
      setMapError("Browser ne podržava geolokaciju.");
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const next = {
          lat: Number(position.coords.latitude.toFixed(7)),
          lng: Number(position.coords.longitude.toFixed(7))
        };
        setPicked(next);
        pickLocationRef.current?.(next.lat, next.lng);
        mapRef.current?.flyTo({ center: [next.lng, next.lat], zoom: 15 });
      },
      (error) => setMapError(error.message)
    );
  }, []);

  return (
    <div className="relative overflow-hidden rounded-3xl border bg-card shadow-sm">
      <div ref={containerRef} className="h-[560px] min-h-[440px] w-full bg-muted md:h-[700px]" />

      <div className="absolute left-4 top-4 z-10 max-w-sm rounded-2xl border bg-background/90 p-3 shadow backdrop-blur">
        <div className="text-sm font-bold">Karta prijava u Splitu</div>
        <p className="mt-1 text-xs text-muted-foreground">
          Prikazuju se samo žute točke/prijave. Kvartovski overlay i obojane zone su uklonjeni radi čišće prezentacije.
        </p>
        <Button onClick={useMyLocation} type="button" size="sm" variant="secondary" className="mt-3">
          Koristi moju lokaciju
        </Button>
        {picked && <p className="mt-2 text-xs">Odabrano: {picked.lat}, {picked.lng}</p>}
      </div>

      <div className="absolute bottom-4 left-4 z-10 rounded-2xl border bg-background/90 px-3 py-2 text-xs shadow backdrop-blur">
        <div>Status: {dataStatus === "live" ? "prijave iz baze" : dataStatus === "loading" ? "učitavanje" : "demo fallback"}</div>
        <div>Prijave: {reports.length}</div>
        <div>Prikaz: samo pinovi</div>
      </div>

      {mapError && (
        <div className="absolute right-4 top-4 z-10 max-w-sm rounded-2xl border border-destructive/40 bg-background/95 p-3 text-xs shadow backdrop-blur">
          <div className="font-bold text-destructive">Mapa koristi sigurni fallback</div>
          <p className="mt-1 text-muted-foreground">{mapError}</p>
        </div>
      )}

      {selectedReport && (
        <div className="absolute bottom-4 left-4 right-4 z-30 rounded-2xl border bg-background/95 p-4 shadow-xl backdrop-blur md:left-auto md:w-96">
          <div className="flex items-start justify-between gap-3">
            <div>
              <Badge className="bg-secondary/30">{REPORT_CATEGORIES[selectedReport.category]}</Badge>
              <h3 className="mt-2 text-lg font-bold">{selectedReport.title}</h3>
              <p className="text-sm text-muted-foreground">
                {selectedReport.neighborhoodName} · score {selectedReport.voteScore}
              </p>
            </div>
            <button className="text-muted-foreground" onClick={() => setSelectedReport(null)}>
              ×
            </button>
          </div>
          <div className="mt-4 flex gap-2">
            {selectedReport.id.startsWith("fallback-") ? (
              <Button disabled>Demo prijava</Button>
            ) : (
              <Button asChild>
                <Link href={`/reports/${selectedReport.id}`}>Otvori prijavu</Link>
              </Button>
            )}
            {!selectedReport.id.startsWith("fallback-") && (
              <Button variant="outline" asChild>
                <Link href={`/events/new?reportId=${selectedReport.id}`}>Organiziraj akciju</Link>
              </Button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
