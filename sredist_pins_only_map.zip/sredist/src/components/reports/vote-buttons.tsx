"use client";

import { ThumbsDown, ThumbsUp } from "lucide-react";
import { voteReportAction } from "@/features/reports/actions";
import { Button } from "@/components/ui/button";

export function VoteButtons({ reportId, score, userVote }: { reportId: string; score: number; userVote: number | null }) {
  const upvote = voteReportAction.bind(null, reportId, 1);
  const downvote = voteReportAction.bind(null, reportId, -1);

  return (
    <div className="flex items-center gap-2 rounded-2xl border bg-card p-2">
      <form action={upvote}>
        <Button type="submit" variant={userVote === 1 ? "default" : "outline"} size="icon" aria-label="Upvote">
          <ThumbsUp className="h-4 w-4" />
        </Button>
      </form>
      <div className="min-w-10 text-center text-lg font-black">{score}</div>
      <form action={downvote}>
        <Button type="submit" variant={userVote === -1 ? "destructive" : "outline"} size="icon" aria-label="Downvote">
          <ThumbsDown className="h-4 w-4" />
        </Button>
      </form>
    </div>
  );
}
