import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { REPORT_CATEGORIES, REPORT_STATUSES } from "@/lib/constants";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

type ReportCardProps = {
  report: {
    id: string;
    title: string;
    description: string;
    category: keyof typeof REPORT_CATEGORIES;
    status: keyof typeof REPORT_STATUSES;
    voteScore: number;
    minPeopleNeeded: number;
    neighborhood?: { name: string } | null;
  };
};

export function ReportCard({ report }: ReportCardProps) {
  const highlightedAt = report.minPeopleNeeded + 5;
  const actionAt = report.minPeopleNeeded + 10;
  const isHot = report.voteScore >= highlightedAt;
  const isActionReady = report.voteScore >= actionAt;

  return (
    <Card className={isHot ? "border-primary/50 bg-primary/5" : undefined}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="flex flex-wrap gap-2">
              <Badge className="bg-secondary/30">{REPORT_CATEGORIES[report.category]}</Badge>
              <Badge>{REPORT_STATUSES[report.status]}</Badge>
              {isActionReady && <Badge className="bg-primary text-primary-foreground">Spremno za akciju</Badge>}
            </div>
            <h3 className="mt-3 text-lg font-bold">{report.title}</h3>
            <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{report.description}</p>
            <p className="mt-2 text-xs text-muted-foreground">{report.neighborhood?.name ?? "Nepoznat kvart"} · score {report.voteScore} · prag isticanja {highlightedAt}</p>
          </div>
          <Button variant="outline" size="icon" asChild>
            <Link href={`/reports/${report.id}`} aria-label="Otvori prijavu"><ArrowUpRight className="h-4 w-4" /></Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
