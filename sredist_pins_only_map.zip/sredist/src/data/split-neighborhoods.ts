import type { Geometry, FeatureCollection, Polygon } from "geojson";

export type SplitNeighborhood = {
  id: string;
  name: string;
  slug: string;
  color: string;
  center: [number, number];
  geojson: Polygon;
  note: string;
};

function polygon(coords: [number, number][]): Polygon {
  const first = coords[0];
  const last = coords[coords.length - 1];
  const closed = first[0] === last[0] && first[1] === last[1] ? coords : [...coords, first];
  return { type: "Polygon", coordinates: [closed] };
}

const sourceNote =
  "Ručna digitalizacija prema dostavljenoj karti narodnih kvartova Splita. Granice su aproksimacija za aplikacijski prikaz, nisu službeni GIS/katastar.";

export const splitNeighborhoods: SplitNeighborhood[] = [
  { id: "kvart-marjan", name: "Marjan", slug: "marjan", color: "#7bb56f", center: [16.3945, 43.5106], note: sourceNote, geojson: polygon([[16.3725,43.5085],[16.3835,43.5198],[16.4050,43.5240],[16.4205,43.5175],[16.4160,43.5050],[16.3960,43.4962],[16.3810,43.4985]]) },
  { id: "kvart-kasuni", name: "Kašuni", slug: "kasuni", color: "#557aa8", center: [16.3920,43.5005], note: sourceNote, geojson: polygon([[16.3830,43.4980],[16.3975,43.4960],[16.4130,43.5015],[16.4075,43.5075],[16.3895,43.5068]]) },
  { id: "kvart-meje", name: "Meje", slug: "meje", color: "#5f8fb5", center: [16.4142,43.5060], note: sourceNote, geojson: polygon([[16.4075,43.5075],[16.4160,43.5050],[16.4242,43.5088],[16.4220,43.5150],[16.4125,43.5168],[16.4040,43.5110]]) },
  { id: "kvart-zvončac", name: "Zvončac", slug: "zvoncac", color: "#d6b342", center: [16.4196,43.5032], note: sourceNote, geojson: polygon([[16.4130,43.5015],[16.4240,43.5022],[16.4278,43.5065],[16.4242,43.5088],[16.4160,43.5050]]) },
  { id: "kvart-mestrovic", name: "Meštrović", slug: "mestrovic", color: "#a36aa6", center: [16.4100,43.4998], note: sourceNote, geojson: polygon([[16.3975,43.4960],[16.4140,43.4972],[16.4240,43.5022],[16.4130,43.5015]]) },
  { id: "kvart-varos", name: "Varoš", slug: "varos", color: "#b35a68", center: [16.4298,43.5102], note: sourceNote, geojson: polygon([[16.4242,43.5088],[16.4278,43.5065],[16.4352,43.5078],[16.4370,43.5130],[16.4310,43.5160],[16.4220,43.5150]]) },
  { id: "kvart-get", name: "Get", slug: "get", color: "#c07d3f", center: [16.4387,43.5081], note: sourceNote, geojson: polygon([[16.4352,43.5078],[16.4418,43.5071],[16.4435,43.5104],[16.4380,43.5122]]) },
  { id: "kvart-dobri", name: "Dobri", slug: "dobri", color: "#64b6b0", center: [16.4380,43.5140], note: sourceNote, geojson: polygon([[16.4370,43.5130],[16.4435,43.5104],[16.4460,43.5158],[16.4410,43.5185],[16.4310,43.5160]]) },
  { id: "kvart-lovret", name: "Lovret", slug: "lovret", color: "#7e79b8", center: [16.4437,43.5165], note: sourceNote, geojson: polygon([[16.4410,43.5185],[16.4460,43.5158],[16.4518,43.5178],[16.4484,43.5220],[16.4400,43.5213]]) },
  { id: "kvart-manus", name: "Manuš", slug: "manus", color: "#e0c146", center: [16.4475,43.5114], note: sourceNote, geojson: polygon([[16.4435,43.5104],[16.4510,43.5090],[16.4532,43.5145],[16.4460,43.5158]]) },
  { id: "kvart-lucac", name: "Lučac", slug: "lucac", color: "#a55763", center: [16.4465,43.5067], note: sourceNote, geojson: polygon([[16.4418,43.5071],[16.4480,43.5040],[16.4522,43.5060],[16.4510,43.5090],[16.4435,43.5104]]) },
  { id: "kvart-spinut", name: "Spinut", slug: "spinut", color: "#6c95bf", center: [16.4325,43.5224], note: sourceNote, geojson: polygon([[16.4205,43.5175],[16.4310,43.5160],[16.4400,43.5213],[16.4385,43.5280],[16.4240,43.5292],[16.4140,43.5240]]) },
  { id: "kvart-poljud", name: "Poljud", slug: "poljud", color: "#4fa6bf", center: [16.4323,43.5181], note: sourceNote, geojson: polygon([[16.4220,43.5150],[16.4310,43.5160],[16.4400,43.5213],[16.4295,43.5220],[16.4205,43.5175]]) },
  { id: "kvart-lora", name: "Lora", slug: "lora", color: "#6aa371", center: [16.4098,43.5228], note: sourceNote, geojson: polygon([[16.4050,43.5240],[16.4140,43.5240],[16.4240,43.5292],[16.4165,43.5360],[16.3970,43.5320]]) },
  { id: "kvart-brodosplit", name: "Brodosplit", slug: "brodosplit", color: "#4777a8", center: [16.4215,43.5307], note: sourceNote, geojson: polygon([[16.4240,43.5292],[16.4385,43.5280],[16.4410,43.5350],[16.4300,43.5400],[16.4165,43.5360]]) },
  { id: "kvart-kopilica", name: "Kopilica", slug: "kopilica", color: "#4d8a91", center: [16.4425,43.5321], note: sourceNote, geojson: polygon([[16.4385,43.5280],[16.4525,43.5282],[16.4560,43.5360],[16.4410,43.5392]]) },
  { id: "kvart-skalice", name: "Skalice", slug: "skalice", color: "#8c5c9e", center: [16.4460,43.5224], note: sourceNote, geojson: polygon([[16.4400,43.5213],[16.4484,43.5220],[16.4525,43.5282],[16.4385,43.5280]]) },
  { id: "kvart-bol", name: "Bol", slug: "bol", color: "#ce7a41", center: [16.4538,43.5181], note: sourceNote, geojson: polygon([[16.4518,43.5178],[16.4590,43.5168],[16.4620,43.5228],[16.4525,43.5282],[16.4484,43.5220]]) },
  { id: "kvart-gripe", name: "Gripe", slug: "gripe", color: "#b24f65", center: [16.4562,43.5107], note: sourceNote, geojson: polygon([[16.4510,43.5090],[16.4600,43.5075],[16.4625,43.5133],[16.4532,43.5145]]) },
  { id: "kvart-bacvice", name: "Bačvice", slug: "bacvice", color: "#d8bd47", center: [16.4506,43.5016], note: sourceNote, geojson: polygon([[16.4480,43.5040],[16.4580,43.5010],[16.4598,43.5065],[16.4522,43.5060]]) },
  { id: "kvart-firule", name: "Firule", slug: "firule", color: "#69b8b6", center: [16.4594,43.5015], note: sourceNote, geojson: polygon([[16.4580,43.5010],[16.4660,43.5002],[16.4678,43.5063],[16.4598,43.5065]]) },
  { id: "kvart-zenta", name: "Zenta", slug: "zenta", color: "#4777a8", center: [16.4648,43.4992], note: sourceNote, geojson: polygon([[16.4580,43.5010],[16.4640,43.4960],[16.4715,43.4988],[16.4660,43.5002]]) },
  { id: "kvart-blatine", name: "Blatine", slug: "blatine", color: "#75b66f", center: [16.4645,43.5102], note: sourceNote, geojson: polygon([[16.4600,43.5075],[16.4695,43.5065],[16.4710,43.5132],[16.4625,43.5133]]) },
  { id: "kvart-lokve", name: "Lokve", slug: "lokve", color: "#7a83bc", center: [16.4663,43.5154], note: sourceNote, geojson: polygon([[16.4625,43.5133],[16.4710,43.5132],[16.4720,43.5190],[16.4620,43.5228],[16.4590,43.5168]]) },
  { id: "kvart-skrape", name: "Škrape", slug: "skrape", color: "#a16aa7", center: [16.4692,43.5216], note: sourceNote, geojson: polygon([[16.4620,43.5228],[16.4720,43.5190],[16.4780,43.5245],[16.4732,43.5290],[16.4620,43.5280]]) },
  { id: "kvart-ravne-njive", name: "Ravne Njive", slug: "ravne-njive", color: "#699dc4", center: [16.4628,43.5328], note: sourceNote, geojson: polygon([[16.4560,43.5360],[16.4732,43.5290],[16.4760,43.5378],[16.4615,43.5430]]) },
  { id: "kvart-brda", name: "Brda", slug: "brda", color: "#c9884b", center: [16.4817,43.5352], note: sourceNote, geojson: polygon([[16.4732,43.5290],[16.4900,43.5285],[16.4930,43.5395],[16.4760,43.5378]]) },
  { id: "kvart-split-3", name: "Split 3", slug: "split-3", color: "#4fa3b2", center: [16.4752,43.5101], note: sourceNote, geojson: polygon([[16.4695,43.5065],[16.4815,43.5060],[16.4838,43.5132],[16.4710,43.5132]]) },
  { id: "kvart-trstenik", name: "Trstenik", slug: "trstenik", color: "#4e78a7", center: [16.4740,43.5005], note: sourceNote, geojson: polygon([[16.4660,43.5002],[16.4715,43.4988],[16.4820,43.4980],[16.4815,43.5060],[16.4695,43.5065],[16.4678,43.5063]]) },
  { id: "kvart-smrdecac", name: "Smrdečac", slug: "smrdecac", color: "#ba5f6f", center: [16.4828,43.5139], note: sourceNote, geojson: polygon([[16.4710,43.5132],[16.4838,43.5132],[16.4860,43.5192],[16.4780,43.5245],[16.4720,43.5190]]) },
  { id: "kvart-sucidar", name: "Sućidar", slug: "sucidar", color: "#d5b83f", center: [16.4848,43.5220], note: sourceNote, geojson: polygon([[16.4780,43.5245],[16.4860,43.5192],[16.4940,43.5225],[16.4900,43.5285]]) },
  { id: "kvart-pujanke", name: "Pujanke", slug: "pujanke", color: "#c88443", center: [16.4912,43.5185], note: sourceNote, geojson: polygon([[16.4860,43.5192],[16.4838,43.5132],[16.4955,43.5130],[16.5000,43.5208],[16.4940,43.5225]]) },
  { id: "kvart-visoka", name: "Visoka", slug: "visoka", color: "#6bb6b7", center: [16.4895,43.5092], note: sourceNote, geojson: polygon([[16.4815,43.5060],[16.4945,43.5060],[16.4955,43.5130],[16.4838,43.5132]]) },
  { id: "kvart-mertojak", name: "Mertojak", slug: "mertojak", color: "#5c77aa", center: [16.4850,43.5017], note: sourceNote, geojson: polygon([[16.4820,43.4980],[16.4935,43.4972],[16.4945,43.5060],[16.4815,43.5060]]) },
  { id: "kvart-krizine", name: "Križine", slug: "krizine", color: "#be7c45", center: [16.4775,43.4965], note: sourceNote, geojson: polygon([[16.4640,43.4960],[16.4770,43.4935],[16.4820,43.4980],[16.4715,43.4988]]) },
  { id: "kvart-znjan", name: "Žnjan", slug: "znjan", color: "#4faeb5", center: [16.4947,43.4968], note: sourceNote, geojson: polygon([[16.4770,43.4935],[16.5010,43.4915],[16.5070,43.5015],[16.4935,43.4972],[16.4820,43.4980]]) },
  { id: "kvart-pazdigrad", name: "Pazdigrad", slug: "pazdigrad", color: "#83bd71", center: [16.5040,43.5067], note: sourceNote, geojson: polygon([[16.4945,43.5060],[16.5070,43.5015],[16.5160,43.5080],[16.5098,43.5150],[16.4955,43.5130]]) },
  { id: "kvart-duilovo", name: "Duilovo", slug: "duilovo", color: "#8476b5", center: [16.5188,43.5015], note: sourceNote, geojson: polygon([[16.5070,43.5015],[16.5205,43.4935],[16.5350,43.5000],[16.5290,43.5090],[16.5160,43.5080]]) },
  { id: "kvart-znjanke", name: "Žnjanke", slug: "znjanke", color: "#7ebdb9", center: [16.5095,43.5137], note: sourceNote, geojson: polygon([[16.5000,43.5208],[16.5098,43.5150],[16.5160,43.5080],[16.5290,43.5090],[16.5260,43.5200],[16.5110,43.5250]]) },
  { id: "kvart-mejasi", name: "Mejaši", slug: "mejasi", color: "#c98545", center: [16.5020,43.5202], note: sourceNote, geojson: polygon([[16.4940,43.5225],[16.5000,43.5208],[16.5110,43.5250],[16.5090,43.5335],[16.4930,43.5395],[16.4900,43.5285]]) },
  { id: "kvart-dragovode", name: "Dragovode", slug: "dragovode", color: "#d5ba3f", center: [16.5052,43.5332], note: sourceNote, geojson: polygon([[16.4930,43.5395],[16.5090,43.5335],[16.5230,43.5360],[16.5180,43.5485],[16.4960,43.5500]]) },
  { id: "kvart-ttts", name: "TTTS", slug: "ttts", color: "#4b80ad", center: [16.5250,43.5373], note: sourceNote, geojson: polygon([[16.5230,43.5360],[16.5420,43.5315],[16.5540,43.5435],[16.5300,43.5510],[16.5180,43.5485]]) },
  { id: "kvart-kila", name: "Kila", slug: "kila", color: "#9d6aab", center: [16.5246,43.5240], note: sourceNote, geojson: polygon([[16.5110,43.5250],[16.5260,43.5200],[16.5420,43.5315],[16.5230,43.5360],[16.5090,43.5335]]) },
  { id: "kvart-kamen", name: "Kamen", slug: "kamen", color: "#64b7ba", center: [16.5440,43.5164], note: sourceNote, geojson: polygon([[16.5260,43.5200],[16.5290,43.5090],[16.5520,43.5060],[16.5660,43.5200],[16.5420,43.5315]]) },
  { id: "kvart-stobrec", name: "Stobreč", slug: "stobrec", color: "#527aaa", center: [16.5360,43.5003], note: sourceNote, geojson: polygon([[16.5205,43.4935],[16.5480,43.4912],[16.5590,43.5000],[16.5520,43.5060],[16.5290,43.5090],[16.5350,43.5000]]) },
  { id: "kvart-sirobuja", name: "Sirobuja", slug: "sirobuja", color: "#c47a46", center: [16.5620,43.5362], note: sourceNote, geojson: polygon([[16.5420,43.5315],[16.5660,43.5200],[16.5980,43.5360],[16.5750,43.5580],[16.5540,43.5435]]) },
  { id: "kvart-karepovac", name: "Karepovac", slug: "karepovac", color: "#d6b642", center: [16.4875,43.5487], note: sourceNote, geojson: polygon([[16.4615,43.5430],[16.4760,43.5378],[16.4930,43.5395],[16.4960,43.5500],[16.4740,43.5570]]) },
  { id: "kvart-dujmovaca", name: "Dujmovača", slug: "dujmovaca", color: "#67b676", center: [16.4405,43.5450], note: sourceNote, geojson: polygon([[16.4300,43.5400],[16.4615,43.5430],[16.4740,43.5570],[16.4510,43.5630],[16.4250,43.5530]]) },
  { id: "kvart-solin-border", name: "Sjeverna Kopilica", slug: "sjeverna-kopilica", color: "#8a74b8", center: [16.4220,43.5460], note: sourceNote, geojson: polygon([[16.4165,43.5360],[16.4300,43.5400],[16.4250,43.5530],[16.4030,43.5470]]) },
  { id: "kvart-zrnovnica", name: "Žrnovnica", slug: "zrnovnica", color: "#c48b4d", center: [16.6025,43.5235], note: sourceNote, geojson: polygon([[16.5660,43.5200],[16.5970,43.5000],[16.6450,43.5130],[16.6500,43.5460],[16.5980,43.5360]]) },
  { id: "kvart-srnjine", name: "Srinjine", slug: "srinjine", color: "#7aa86b", center: [16.6550,43.5300], note: sourceNote, geojson: polygon([[16.6450,43.5130],[16.6900,43.5200],[16.6940,43.5550],[16.6500,43.5460]]) },
  { id: "kvart-gornje-sitno", name: "Gornje Sitno", slug: "gornje-sitno", color: "#9077ba", center: [16.7020,43.5055], note: sourceNote, geojson: polygon([[16.6450,43.5130],[16.6800,43.4860],[16.7300,43.4940],[16.6900,43.5200]]) },
  { id: "kvart-donje-sitno", name: "Donje Sitno", slug: "donje-sitno", color: "#d2ad40", center: [16.6640,43.4850], note: sourceNote, geojson: polygon([[16.5970,43.5000],[16.6350,43.4750],[16.6800,43.4860],[16.6450,43.5130]]) }
];

export const splitNeighborhoodFeatureCollection: FeatureCollection<Geometry, {
  id: string;
  name: string;
  slug: string;
  color: string;
  note: string;
  reportCount: number;
}> = {
  type: "FeatureCollection",
  features: splitNeighborhoods.map((neighborhood) => ({
    type: "Feature",
    properties: {
      id: neighborhood.id,
      name: neighborhood.name,
      slug: neighborhood.slug,
      color: neighborhood.color,
      note: neighborhood.note,
      reportCount: 0
    },
    geometry: neighborhood.geojson
  }))
};

export const splitNeighborhoodOptions = splitNeighborhoods.map((neighborhood) => ({
  id: neighborhood.slug,
  name: neighborhood.name,
  slug: neighborhood.slug
}));

export const splitNeighborhoodLookup = Object.fromEntries(
  splitNeighborhoods.map((neighborhood) => [neighborhood.slug, neighborhood])
);
