# Split neighborhood map implementation

This version replaces the temporary fake/demo neighborhood polygons with a static application-level map of real Split neighborhood names.

## What changed

- Added `src/data/split-neighborhoods.ts` with 53 named Split neighborhoods/areas.
- Polygons are manually digitized as approximate GeoJSON polygons based on the provided “Karta narodnih kvartova Splita” reference image.
- `SplitMap` now always renders this neighborhood layer, regardless of whether the database has seeded neighborhoods.
- MapLibre still uses OpenStreetMap raster tiles as the base map.
- Neighborhoods are color-coded by polygon, with white outlines and labels at higher zoom.
- Clicking a neighborhood opens a small info card.
- Clicking the map still selects coordinates for a new report.
- Existing report markers and heatmap remain functional.
- `scripts/seed.ts` now seeds all static neighborhoods instead of the old 8 placeholder areas.

## Accuracy note

These polygons are intentionally a middle-ground implementation: usable and visually aligned for the application, but not official GIS/cadastral boundaries. For official production accuracy, replace `src/data/split-neighborhoods.ts` with a verified municipal GeoJSON/Shapefile source.

## Run

```bash
npm install
npm run dev
```

Open:

```text
http://localhost:3000/map
```

## Optional local database reseed

If you use Supabase locally and want the report form/dropdowns to contain the updated neighborhoods:

```bash
npm run supabase:reset
npm run db:seed
```

or, if your local database is already running:

```bash
npm run db:seed
```
