# Map mode: pins only

This version removes the colored neighborhood polygon overlay from the MapLibre map.

The map now shows:

- OpenStreetMap raster base map
- yellow report points / pins
- report click popup card
- location picking by clicking an empty map area
- fallback demo pins if `/api/map` returns no usable report coordinates

Removed from the map component:

- neighborhood GeoJSON source
- neighborhood fill layer
- neighborhood outline layer
- selected neighborhood outline
- neighborhood labels
- neighborhood info card
- heatmap layer

The database/schema can still keep neighborhoods because reports and forms may still reference them, but the visual map is now intentionally cleaner for demo presentation.
