# Temporary pin + action promotion flow

This version adds the requested map-driven action input flow.

## What changed

- Clicking an empty place on the map now creates a visible temporary pin.
- The temporary pin coordinates are automatically passed into the action/report form.
- `/events/new` now includes the map above the action form, so users can choose the action location visually.
- The action form shows the selected coordinates and submits them as `latitude` and `longitude`.
- The map now loads both:
  - published/rescheduled events, shown as stronger yellow pins with green outline;
  - report/proposal pins, shown as softer yellow pins.
- When a report/proposal reaches its `minPeopleNeeded` upvote threshold, `voteReportAction` automatically creates a published event at the same coordinates and marks the report as `converted_to_event`.
- Converted reports are removed from the proposal layer so the new event pin becomes the visible map object.

## Demo path

1. Open `/map`.
2. Log in as a demo user.
3. Click on the map: a temporary pin appears.
4. Fill in the proposal form below the map. The coordinates are already filled.
5. Submit the proposal.
6. Open the proposal and upvote it using enough test users.
7. Once the vote score reaches the needed threshold, the proposal becomes a published event and appears as a main yellow event pin.

## Notes

This does not use colored neighborhood zones. The map remains pins-only.
