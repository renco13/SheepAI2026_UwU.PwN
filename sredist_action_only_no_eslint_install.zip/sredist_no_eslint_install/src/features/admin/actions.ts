"use server";

import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { db } from "@/db";
import { events, users } from "@/db/schema";
import { getCurrentUser, requireAdmin } from "@/lib/auth";

const eventStatusSchema = z.enum(["draft", "published", "rescheduled", "completed", "cancelled"]);

export async function updateEventStatusAction(eventId: string, formData: FormData) {
  const user = await getCurrentUser();
  requireAdmin(user);

  const parsed = eventStatusSchema.safeParse(formData.get("status"));
  if (!parsed.success) return;

  await db.update(events).set({ status: parsed.data, updatedAt: new Date() }).where(eq(events.id, eventId));
  revalidatePath("/admin");
  revalidatePath("/map");
  revalidatePath(`/events/${eventId}`);
}

export async function approveOrganizationAction(userId: string) {
  const user = await getCurrentUser();
  requireAdmin(user);

  await db.update(users).set({ organizationStatus: "approved", updatedAt: new Date() }).where(eq(users.id, userId));
  revalidatePath("/admin");
}

export async function rejectOrganizationAction(userId: string) {
  const user = await getCurrentUser();
  requireAdmin(user);

  await db.update(users).set({ organizationStatus: "rejected", updatedAt: new Date() }).where(eq(users.id, userId));
  revalidatePath("/admin");
}
