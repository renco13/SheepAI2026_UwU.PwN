import type { Metadata } from "next";
import "./globals.css";
import { AppShell } from "@/components/layout/app-shell";
import { getCurrentUser } from "@/lib/auth";


export const metadata: Metadata = {
  title: "SrediST",
  description: "Građanske prijave i zelene akcije za Split"
};

export default async function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  const user = await getCurrentUser();

  return (
    <html lang="hr">
      <body>
        <AppShell user={user}>{children}</AppShell>
      </body>
    </html>
  );
}
