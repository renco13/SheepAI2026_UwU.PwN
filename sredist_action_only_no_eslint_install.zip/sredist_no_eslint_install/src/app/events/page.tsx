import Link from "next/link";
import { asc, desc, inArray, notInArray } from "drizzle-orm";
import { db } from "@/db";
import { events } from "@/db/schema";
import { EventCard } from "@/components/events/event-card";
import { Button } from "@/components/ui/button";

export default async function EventsPage() {
  const activeRows = await db.query.events.findMany({
    where: notInArray(events.status, ["completed", "cancelled", "draft"]),
    with: { organizer: true, participants: true },
    orderBy: [asc(events.startsAt)]
  });

  const historyRows = await db.query.events.findMany({
    where: inArray(events.status, ["completed", "cancelled"]),
    with: { organizer: true, participants: true },
    orderBy: [desc(events.updatedAt)],
    limit: 6
  });

  return (
    <div className="space-y-8 pb-24">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-3xl font-black">Akcije volontiranja</h1>
          <p className="text-muted-foreground">Pokreni akciju klikom na kartu, a zatim pozovi građane da se priključe.</p>
        </div>
        <Button asChild><Link href="/events/new">Unesi akciju</Link></Button>
      </div>

      <section className="space-y-4">
        <h2 className="text-xl font-black">Aktivne akcije</h2>
        {activeRows.length === 0 ? <p className="text-muted-foreground">Još nema aktivnih akcija.</p> : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {activeRows.map((event) => <EventCard key={event.id} event={event} />)}
          </div>
        )}
      </section>

      {historyRows.length > 0 && (
        <section className="space-y-4">
          <h2 className="text-xl font-black">Završene i otkazane akcije</h2>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {historyRows.map((event) => <EventCard key={event.id} event={event} />)}
          </div>
        </section>
      )}
    </div>
  );
}
