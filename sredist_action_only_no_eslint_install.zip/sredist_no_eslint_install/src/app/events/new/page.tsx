import { redirect } from "next/navigation";
import { EventMapWorkspace } from "@/components/events/event-map-workspace";
import { getCurrentUser } from "@/lib/auth";

export default async function NewEventPage({ searchParams }: { searchParams: { error?: string } }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  return (
    <div className="mx-auto max-w-6xl space-y-4 pb-24">
      <div>
        <h1 className="text-3xl font-black">Unos nove akcije</h1>
        <p className="text-muted-foreground">
          Klikni na kartu za preciznu lokaciju. Privremeni pin se automatski upisuje u formu ispod karte.
        </p>
      </div>
      {searchParams.error && (
        <div className="rounded-2xl border border-destructive/30 bg-destructive/10 p-3 text-sm text-destructive">
          Akcija nije spremljena. Provjeri naslov, opis, vrijeme, opis lokacije i odaberi lokaciju klikom na kartu.
        </div>
      )}
      <EventMapWorkspace />
    </div>
  );
}
