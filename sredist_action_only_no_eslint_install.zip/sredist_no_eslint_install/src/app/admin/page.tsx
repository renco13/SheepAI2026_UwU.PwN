import { desc, eq } from "drizzle-orm";
import { redirect } from "next/navigation";
import { approveOrganizationAction, rejectOrganizationAction, updateEventStatusAction } from "@/features/admin/actions";
import { db } from "@/db";
import { events, users } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { EVENT_CATEGORIES, EVENT_STATUSES, ORGANIZATION_STATUSES } from "@/lib/constants";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Select } from "@/components/ui/select";

export default async function AdminPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (user.role !== "admin") redirect("/dashboard");

  const eventRows = await db.query.events.findMany({
    with: { organizer: true, participants: true },
    orderBy: [desc(events.createdAt)],
    limit: 30
  });

  const pendingOrganizations = await db.query.users.findMany({
    where: eq(users.organizationStatus, "pending"),
    orderBy: [desc(users.createdAt)]
  });

  return (
    <div className="space-y-6 pb-24">
      <div>
        <h1 className="text-3xl font-black">Admin panel</h1>
        <p className="text-muted-foreground">Ručna kontrola sustava, odobrenje udruga i status akcija.</p>
      </div>

      <section className="grid gap-4 md:grid-cols-3">
        <Card><CardContent className="p-5"><p className="text-sm text-muted-foreground">Akcija u panelu</p><p className="text-3xl font-black">{eventRows.length}</p></CardContent></Card>
        <Card><CardContent className="p-5"><p className="text-sm text-muted-foreground">Udruge čekaju</p><p className="text-3xl font-black">{pendingOrganizations.length}</p></CardContent></Card>
        <Card><CardContent className="p-5"><p className="text-sm text-muted-foreground">Demo status</p><p className="text-3xl font-black">aktivno</p></CardContent></Card>
      </section>

      <section className="space-y-3">
        <h2 className="text-xl font-black">Odobrenje udruga</h2>
        {pendingOrganizations.length === 0 ? <p className="text-muted-foreground">Nema udruga na čekanju.</p> : pendingOrganizations.map((org) => (
          <Card key={org.id}>
            <CardContent className="flex flex-wrap items-center justify-between gap-3 p-4">
              <div>
                <h3 className="font-bold">{org.displayName}</h3>
                <p className="text-sm text-muted-foreground">{org.email} · OIB {org.organizationOib} · {org.organizationStatus ? ORGANIZATION_STATUSES[org.organizationStatus] : "Nepoznato"}</p>
              </div>
              <div className="flex gap-2">
                <form action={approveOrganizationAction.bind(null, org.id)}><Button type="submit">Odobri</Button></form>
                <form action={rejectOrganizationAction.bind(null, org.id)}><Button type="submit" variant="destructive">Odbij</Button></form>
              </div>
            </CardContent>
          </Card>
        ))}
      </section>

      <section className="space-y-3">
        <h2 className="text-xl font-black">Akcije</h2>
        <div className="grid gap-3">
          {eventRows.map((event) => {
            const updateStatus = updateEventStatusAction.bind(null, event.id);
            const volunteerCount = event.participants.filter((participant) => participant.status === "joined").length;
            return (
              <Card key={event.id}>
                <CardContent className="grid gap-4 p-4 lg:grid-cols-[1fr_260px]">
                  <div>
                    <div className="flex flex-wrap gap-2">
                      <Badge>{EVENT_CATEGORIES[event.category]}</Badge>
                      <Badge>{EVENT_STATUSES[event.status]}</Badge>
                    </div>
                    <h3 className="mt-2 text-lg font-bold">{event.title}</h3>
                    <p className="mt-1 text-sm text-muted-foreground">{event.locationText} · {volunteerCount}{event.maxParticipants ? `/${event.maxParticipants}` : ""} volontera</p>
                    <p className="mt-2 line-clamp-2 text-sm">{event.description}</p>
                  </div>
                  <form action={updateStatus} className="space-y-2">
                    <Select name="status" defaultValue={event.status}>
                      {Object.entries(EVENT_STATUSES).map(([value, label]) => <option key={value} value={value}>{label}</option>)}
                    </Select>
                    <Button type="submit" className="w-full">Spremi status</Button>
                  </form>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </section>
    </div>
  );
}
