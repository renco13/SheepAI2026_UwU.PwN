import { asc, notInArray } from "drizzle-orm";
import { SplitMap } from "@/components/map/split-map";
import { EventMapWorkspace } from "@/components/events/event-map-workspace";
import { EventCard } from "@/components/events/event-card";
import { db } from "@/db";
import { events } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export default async function MapPage() {
  const user = await getCurrentUser();
  const upcomingEvents = await db.query.events.findMany({
    where: notInArray(events.status, ["completed", "cancelled", "draft"]),
    with: { organizer: true, participants: true },
    orderBy: [asc(events.startsAt)],
    limit: 6
  });

  return (
    <div className="grid gap-6 pb-24 lg:grid-cols-[1fr_420px]">
      <section className="space-y-4">
        <div>
          <h1 className="text-3xl font-black">Karta Splita</h1>
          <p className="text-muted-foreground">
            Karta prikazuje žute pinove za aktivne akcije. Klik na praznu kartu postavlja privremeni pin koji se automatski upisuje u unos nove akcije.
          </p>
        </div>
        {user ? <EventMapWorkspace /> : <SplitMap />}
        <div className="grid gap-3 md:grid-cols-3">
          <Card><CardContent className="p-4"><p className="text-sm text-muted-foreground">Prikaz</p><p className="text-2xl font-black">akcije</p></CardContent></Card>
          <Card><CardContent className="p-4"><p className="text-sm text-muted-foreground">Engine</p><p className="text-2xl font-black">MapLibre</p></CardContent></Card>
          <Card><CardContent className="p-4"><p className="text-sm text-muted-foreground">Odabir</p><p className="text-2xl font-black">privremeni pin</p></CardContent></Card>
        </div>
      </section>
      <aside className="space-y-4">
        {!user && (
          <Card><CardContent className="p-5"><h2 className="text-xl font-bold">Želiš pokrenuti akciju?</h2><p className="mt-2 text-sm text-muted-foreground">Za unos akcije, volontiranje i upravljanje svojim akcijama moraš biti prijavljen.</p><Button asChild className="mt-4"><Link href="/login">Prijavi se</Link></Button></CardContent></Card>
        )}
        <div className="space-y-3">
          <h2 className="text-xl font-black">Aktivne akcije</h2>
          {upcomingEvents.length === 0 ? <p className="text-muted-foreground">Još nema aktivnih akcija.</p> : upcomingEvents.map((event) => <EventCard key={event.id} event={event} />)}
        </div>
      </aside>
    </div>
  );
}
