import { NextResponse } from "next/server";
import { notInArray } from "drizzle-orm";
import { db } from "@/db";
import { events } from "@/db/schema";

export async function GET() {
  const eventRows = await db.query.events.findMany({
    where: notInArray(events.status, ["completed", "cancelled", "draft"]),
    with: { organizer: true, participants: true },
    orderBy: (table, { asc }) => [asc(table.startsAt)]
  });

  return NextResponse.json({
    events: eventRows.map((event) => ({
      id: event.id,
      title: event.title,
      category: event.category,
      status: event.status,
      latitude: Number(event.latitude),
      longitude: Number(event.longitude),
      locationText: event.locationText,
      startsAt: event.startsAt.toISOString(),
      participantCount: event.participants.filter((participant) => participant.status === "joined").length,
      maxParticipants: event.maxParticipants
    }))
  });
}
