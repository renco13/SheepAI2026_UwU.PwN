"use client";

import { useState } from "react";
import { EventForm } from "@/components/events/event-form";
import { SplitMap } from "@/components/map/split-map";
import { EVENT_CATEGORIES } from "@/lib/constants";

type EventCreationWorkspaceProps = {
  report?: {
    id: string;
    title: string;
    description: string;
    category: keyof typeof EVENT_CATEGORIES;
    latitude: string;
    longitude: string;
    locationDescription: string | null;
  } | null;
};

export function EventCreationWorkspace({ report }: EventCreationWorkspaceProps) {
  const [pickedLocation, setPickedLocation] = useState<{ lat: number; lng: number } | null>(
    report ? { lat: Number(report.latitude), lng: Number(report.longitude) } : null
  );

  return (
    <div className="space-y-4">
      <SplitMap onPickLocation={(lat, lng) => setPickedLocation({ lat, lng })} initialPickedLocation={pickedLocation} />
      <EventForm report={report} pickedLocation={pickedLocation} />
    </div>
  );
}
