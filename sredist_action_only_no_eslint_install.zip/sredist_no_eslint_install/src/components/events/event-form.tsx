"use client";

import { useEffect, useMemo, useState } from "react";
import { createEventAction } from "@/features/events/actions";
import { EVENT_CATEGORIES } from "@/lib/constants";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

type EventFormProps = {
  report?: {
    id: string;
    title: string;
    description: string;
    category: keyof typeof EVENT_CATEGORIES;
    latitude: string;
    longitude: string;
    locationDescription: string | null;
  } | null;
  pickedLocation?: { lat: number; lng: number } | null;
};

function toLocalInput(date: Date) {
  return new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
}

export function EventForm({ report, pickedLocation }: EventFormProps) {
  const defaultTimes = useMemo(() => {
    const start = new Date(Date.now() + 24 * 60 * 60 * 1000);
    start.setHours(10, 0, 0, 0);
    const end = new Date(start);
    end.setHours(13, 0, 0, 0);
    return { start, end };
  }, []);

  const [lat, setLat] = useState<string>(() => (report ? String(report.latitude) : ""));
  const [lng, setLng] = useState<string>(() => (report ? String(report.longitude) : ""));
  const hasPickedLocation = lat.trim().length > 0 && lng.trim().length > 0;

  useEffect(() => {
    if (pickedLocation) {
      setLat(pickedLocation.lat.toFixed(7));
      setLng(pickedLocation.lng.toFixed(7));
    }
  }, [pickedLocation]);

  return (
    <form action={createEventAction} className="space-y-4 rounded-3xl border bg-card p-5 shadow-sm">
      <input type="hidden" name="reportId" value={report?.id ?? ""} />

      <div>
        <h1 className="text-2xl font-black">Unesi akciju</h1>
        <p className="text-sm text-muted-foreground">
          Prvo klikni na kartu. Privremeni žuti pin označava mjesto održavanja akcije, a koordinate se automatski spremaju u formu.
        </p>
      </div>

      {hasPickedLocation ? (
        <div className="rounded-2xl border border-primary/30 bg-primary/10 p-3 text-sm text-primary">
          Lokacija odabrana na karti: {lat}, {lng}
        </div>
      ) : (
        <div className="rounded-2xl border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900">
          Klikni na kartu prije slanja akcije. Bez odabrane lokacije akcija se neće moći objaviti.
        </div>
      )}

      <div className="space-y-2">
        <Label htmlFor="title">Naslov akcije</Label>
        <Input id="title" name="title" required defaultValue={report ? `Akcija: ${report.title}` : ""} placeholder="Npr. Čišćenje plaže na Žnjanu" />
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Opis akcije</Label>
        <Textarea id="description" name="description" required defaultValue={report?.description ?? ""} placeholder="Objasni što treba napraviti, zašto je korisno i što volonteri trebaju ponijeti." />
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="category">Kategorija</Label>
          <Select id="category" name="category" defaultValue={report?.category ?? "green_area"}>
            {Object.entries(EVENT_CATEGORIES).map(([value, label]) => <option key={value} value={value}>{label}</option>)}
          </Select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="locationText">Opis lokacije</Label>
          <Input id="locationText" name="locationText" required defaultValue={report?.locationDescription ?? ""} placeholder="Npr. kod istočnog ulaza u park" />
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="startsAt">Početak</Label>
          <Input id="startsAt" name="startsAt" type="datetime-local" required defaultValue={toLocalInput(defaultTimes.start)} />
        </div>
        <div className="space-y-2">
          <Label htmlFor="endsAt">Kraj</Label>
          <Input id="endsAt" name="endsAt" type="datetime-local" required defaultValue={toLocalInput(defaultTimes.end)} />
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <div className="space-y-2">
          <Label htmlFor="latitude">Latitude</Label>
          <Input id="latitude" name="latitude" required readOnly value={lat} placeholder="Klikni na kartu" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="longitude">Longitude</Label>
          <Input id="longitude" name="longitude" required readOnly value={lng} placeholder="Klikni na kartu" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="maxParticipants">Max volontera</Label>
          <Input id="maxParticipants" name="maxParticipants" type="number" min="1" placeholder="Bez limita" />
        </div>
      </div>

      <Button type="submit" className="w-full" disabled={!hasPickedLocation}>Unesi akciju</Button>
    </form>
  );
}
