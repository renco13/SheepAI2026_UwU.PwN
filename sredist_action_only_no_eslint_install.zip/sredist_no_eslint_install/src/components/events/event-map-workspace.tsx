"use client";

import { useState } from "react";
import { EventForm } from "@/components/events/event-form";
import { SplitMap } from "@/components/map/split-map";

export function EventMapWorkspace() {
  const [pickedLocation, setPickedLocation] = useState<{ lat: number; lng: number } | null>(null);

  return (
    <div className="space-y-4">
      <SplitMap onPickLocation={(lat, lng) => setPickedLocation({ lat, lng })} initialPickedLocation={pickedLocation} />
      <EventForm pickedLocation={pickedLocation} />
    </div>
  );
}
