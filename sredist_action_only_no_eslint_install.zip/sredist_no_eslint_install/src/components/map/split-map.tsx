"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import maplibregl, { GeoJSONSource, StyleSpecification } from "maplibre-gl";
import type { Map as MapLibreMap, Marker } from "maplibre-gl";
import type { FeatureCollection, Point } from "geojson";
import { EVENT_CATEGORIES, SPLIT_CENTER } from "@/lib/constants";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

type MapEvent = {
  id: string;
  title: string;
  category: keyof typeof EVENT_CATEGORIES;
  status: string;
  latitude: number;
  longitude: number;
  locationText: string;
  startsAt: string;
  participantCount: number;
  maxParticipants: number | null;
};

type EventProperties = {
  id: string;
  title: string;
  category: keyof typeof EVENT_CATEGORIES;
  kind: "event";
};

const rasterMapStyle: StyleSpecification = {
  version: 8,
  sources: {
    osm: {
      type: "raster",
      tiles: ["https://tile.openstreetmap.org/{z}/{x}/{y}.png"],
      tileSize: 256,
      attribution: "© OpenStreetMap contributors"
    }
  },
  layers: [
    {
      id: "osm-raster-tiles",
      type: "raster",
      source: "osm",
      minzoom: 0,
      maxzoom: 19,
      paint: { "raster-saturation": -0.18, "raster-contrast": 0.04 }
    }
  ]
};

const fallbackEvents: MapEvent[] = [
  {
    id: "fallback-event-znjan",
    title: "Demo akcija: Čišćenje Žnjana",
    category: "beach",
    status: "published",
    latitude: 43.4989,
    longitude: 16.4916,
    locationText: "Žnjan, istočni dio plaže",
    startsAt: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(),
    participantCount: 8,
    maxParticipants: 30
  },
  {
    id: "fallback-event-mertojak",
    title: "Demo akcija: Uređenje zelenila",
    category: "green_area",
    status: "published",
    latitude: 43.5034,
    longitude: 16.4769,
    locationText: "Mertojak, dvorište između zgrada",
    startsAt: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000).toISOString(),
    participantCount: 5,
    maxParticipants: 15
  }
];

function isValidCoordinate(latitude: number, longitude: number) {
  return (
    Number.isFinite(latitude) &&
    Number.isFinite(longitude) &&
    latitude >= -90 &&
    latitude <= 90 &&
    longitude >= -180 &&
    longitude <= 180
  );
}

function normalizeEvents(payload: unknown): MapEvent[] | null {
  if (!payload || typeof payload !== "object") return null;

  const maybePayload = payload as Partial<{ events: Partial<MapEvent>[] }>;
  const events = Array.isArray(maybePayload.events) ? maybePayload.events : [];

  const validEvents = events
    .map((event) => ({
      ...event,
      id: String(event.id ?? ""),
      title: String(event.title ?? ""),
      category: event.category as keyof typeof EVENT_CATEGORIES,
      status: String(event.status ?? "published"),
      latitude: Number(event.latitude),
      longitude: Number(event.longitude),
      locationText: String(event.locationText ?? "Split"),
      startsAt: String(event.startsAt ?? ""),
      participantCount: Number(event.participantCount ?? 0),
      maxParticipants: event.maxParticipants === null || event.maxParticipants === undefined ? null : Number(event.maxParticipants)
    }))
    .filter((event): event is MapEvent => {
      return Boolean(
        event.id &&
        event.title &&
        event.category &&
        isValidCoordinate(event.latitude, event.longitude)
      );
    });

  return validEvents;
}

function createPickedMarkerElement() {
  const wrapper = document.createElement("div");
  wrapper.className = "relative flex h-12 w-12 items-center justify-center";
  wrapper.innerHTML = `
    <div style="position:absolute; width:48px; height:48px; border-radius:999px; background:rgba(242,183,83,0.22); border:2px solid rgba(20,83,45,0.25);"></div>
    <div style="position:absolute; width:22px; height:22px; border-radius:999px 999px 999px 0; transform:rotate(-45deg); background:#f2b753; border:3px solid #14532d; box-shadow:0 10px 20px rgba(15,23,42,0.35);"></div>
    <div style="position:absolute; width:8px; height:8px; border-radius:999px; background:#14532d; top:17px;"></div>
  `;
  return wrapper;
}

export function SplitMap({ onPickLocation, initialPickedLocation }: { onPickLocation?: (lat: number, lng: number) => void; initialPickedLocation?: { lat: number; lng: number } | null }) {
  const mapRef = useRef<MapLibreMap | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const eventsRef = useRef<MapEvent[]>(fallbackEvents);
  const pickedMarkerRef = useRef<Marker | null>(null);
  const pickLocationRef = useRef<typeof onPickLocation>(onPickLocation);

  const [events, setEvents] = useState<MapEvent[]>(fallbackEvents);
  const [selectedEvent, setSelectedEvent] = useState<MapEvent | null>(null);
  const [picked, setPicked] = useState<{ lat: number; lng: number } | null>(initialPickedLocation ?? null);
  const [mapReady, setMapReady] = useState(false);
  const [dataStatus, setDataStatus] = useState<"loading" | "live" | "fallback">("loading");
  const [mapError, setMapError] = useState<string | null>(null);

  useEffect(() => {
    eventsRef.current = events;
  }, [events]);

  useEffect(() => {
    pickLocationRef.current = onPickLocation;
  }, [onPickLocation]);

  useEffect(() => {
    let cancelled = false;

    async function loadMapData() {
      try {
        const response = await fetch("/api/map", { cache: "no-store" });
        if (!response.ok) throw new Error(`API /api/map returned ${response.status}`);

        const payload = await response.json();
        const normalizedEvents = normalizeEvents(payload);

        if (!cancelled && normalizedEvents) {
          setEvents(normalizedEvents);
          setDataStatus("live");
          return;
        }

        if (!cancelled) {
          setEvents(fallbackEvents);
          setDataStatus("fallback");
        }
      } catch (error) {
        console.error("Map data loading failed", error);
        if (!cancelled) {
          setEvents(fallbackEvents);
          setDataStatus("fallback");
          setMapError(error instanceof Error ? error.message : "Neuspjelo učitavanje map podataka.");
        }
      }
    }

    loadMapData();

    return () => {
      cancelled = true;
    };
  }, []);

  const eventsFeatureCollection = useMemo<FeatureCollection<Point, EventProperties>>(() => {
    return {
      type: "FeatureCollection",
      features: events.map((event) => ({
        type: "Feature",
        properties: {
          id: event.id,
          title: event.title,
          category: event.category,
          kind: "event"
        },
        geometry: { type: "Point", coordinates: [event.longitude, event.latitude] }
      }))
    };
  }, [events]);

  const chooseLocation = useCallback((lat: number, lng: number) => {
    const next = { lat: Number(lat.toFixed(7)), lng: Number(lng.toFixed(7)) };
    setPicked(next);
    setSelectedEvent(null);
    pickLocationRef.current?.(next.lat, next.lng);
  }, []);

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const map = new maplibregl.Map({
      container: containerRef.current,
      style: rasterMapStyle,
      center: [SPLIT_CENTER.lng, SPLIT_CENTER.lat],
      zoom: 12.1,
      minZoom: 10,
      maxZoom: 18,
      pitch: 0
    });

    map.addControl(new maplibregl.NavigationControl({ visualizePitch: true }), "top-right");
    mapRef.current = map;

    const resizeMap = () => map.resize();
    const resizeObserver = new ResizeObserver(resizeMap);
    resizeObserver.observe(containerRef.current);

    const resizeTimers = [100, 350, 800].map((delay) => window.setTimeout(resizeMap, delay));

    map.on("load", () => {
      setMapReady(true);
      resizeMap();
    });

    map.on("error", (event) => {
      console.error("MapLibre error", event.error);
      setMapError(event.error?.message ?? "Greška pri učitavanju karte.");
    });

    map.on("mousemove", (event) => {
      const features = map.getLayer("event-points") ? map.queryRenderedFeatures(event.point, { layers: ["event-points"] }) : [];
      map.getCanvas().style.cursor = features.length > 0 ? "pointer" : "crosshair";
    });

    map.on("mouseleave", () => {
      map.getCanvas().style.cursor = "";
    });

    map.on("click", (event) => {
      if (map.getLayer("event-points")) {
        const eventFeatures = map.queryRenderedFeatures(event.point, { layers: ["event-points"] });
        if (eventFeatures.length > 0) {
          const eventId = eventFeatures[0].properties?.id;
          const mapEvent = eventsRef.current.find((item) => item.id === eventId);
          if (mapEvent) setSelectedEvent(mapEvent);
          return;
        }
      }

      chooseLocation(event.lngLat.lat, event.lngLat.lng);
    });

    return () => {
      resizeTimers.forEach((timer) => window.clearTimeout(timer));
      resizeObserver.disconnect();
      pickedMarkerRef.current?.remove();
      pickedMarkerRef.current = null;
      map.remove();
      mapRef.current = null;
    };
  }, [chooseLocation]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapReady) return;

    if (!map.getSource("events")) {
      map.addSource("events", { type: "geojson", data: eventsFeatureCollection });
      map.addLayer({
        id: "event-point-halo",
        type: "circle",
        source: "events",
        minzoom: 10,
        paint: {
          "circle-radius": 18,
          "circle-color": "#f2b753",
          "circle-opacity": 0.24,
          "circle-stroke-width": 0
        }
      });
      map.addLayer({
        id: "event-points",
        type: "circle",
        source: "events",
        minzoom: 10,
        paint: {
          "circle-radius": 11,
          "circle-color": "#f2b753",
          "circle-stroke-color": "#14532d",
          "circle-stroke-width": 3,
          "circle-opacity": 0.98
        }
      });
    } else {
      (map.getSource("events") as GeoJSONSource).setData(eventsFeatureCollection);
    }

    map.resize();
  }, [mapReady, eventsFeatureCollection]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapReady) return;

    if (!picked) {
      pickedMarkerRef.current?.remove();
      pickedMarkerRef.current = null;
      return;
    }

    if (!pickedMarkerRef.current) {
      pickedMarkerRef.current = new maplibregl.Marker({
        element: createPickedMarkerElement(),
        anchor: "bottom"
      }).setLngLat([picked.lng, picked.lat]).addTo(map);
    } else {
      pickedMarkerRef.current.setLngLat([picked.lng, picked.lat]);
    }
  }, [mapReady, picked]);

  const useMyLocation = useCallback(() => {
    if (!navigator.geolocation) {
      setMapError("Browser ne podržava geolokaciju.");
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const lat = Number(position.coords.latitude.toFixed(7));
        const lng = Number(position.coords.longitude.toFixed(7));
        chooseLocation(lat, lng);
        mapRef.current?.flyTo({ center: [lng, lat], zoom: 15 });
      },
      (error) => setMapError(error.message)
    );
  }, [chooseLocation]);

  return (
    <div className="overflow-hidden rounded-[2rem] border bg-card shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b p-4">
        <div>
          <h2 className="text-xl font-black">Karta akcija</h2>
          <p className="text-sm text-muted-foreground">Žuti pinovi su aktivne akcije. Klik na praznu kartu postavlja privremeni pin za novu akciju.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Badge>{dataStatus === "loading" ? "Učitavanje" : dataStatus === "live" ? "Live podaci" : "Demo podaci"}</Badge>
          <Button type="button" variant="outline" onClick={useMyLocation}>Moja lokacija</Button>
        </div>
      </div>

      {mapError && <div className="border-b bg-destructive/10 p-3 text-sm text-destructive">{mapError}</div>}

      <div className="relative h-[560px] min-h-[420px] w-full">
        <div ref={containerRef} className="h-full w-full" />
        {picked && (
          <div className="absolute bottom-4 left-4 z-10 rounded-2xl bg-background/95 p-3 text-sm shadow">
            <strong>Odabrano mjesto:</strong> {picked.lat}, {picked.lng}
          </div>
        )}
      </div>

      {selectedEvent && (
        <div className="border-t bg-background p-4">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <Badge className="bg-primary/10 text-primary">{EVENT_CATEGORIES[selectedEvent.category]}</Badge>
              <h3 className="mt-2 text-lg font-black">{selectedEvent.title}</h3>
              <p className="text-sm text-muted-foreground">{selectedEvent.locationText}</p>
              <p className="mt-1 text-sm text-muted-foreground">
                Volontera: {selectedEvent.participantCount}{selectedEvent.maxParticipants ? `/${selectedEvent.maxParticipants}` : ""}
              </p>
            </div>
            <Button asChild><Link href={`/events/${selectedEvent.id}`}>Otvori akciju</Link></Button>
          </div>
        </div>
      )}
    </div>
  );
}
