# Fast install notes

This package removes ESLint from `devDependencies` to avoid slow/stuck npm installation during the hackathon demo.

ESLint is not required to run the app locally with `npm run dev`. The app still uses Next.js, TypeScript, Tailwind, MapLibre, Drizzle and Supabase-related scripts.

Run:

```bash
npm install --no-audit --no-fund --loglevel=error
npm run dev
```

If you need linting later, reinstall:

```bash
npm install -D eslint eslint-config-next
```
