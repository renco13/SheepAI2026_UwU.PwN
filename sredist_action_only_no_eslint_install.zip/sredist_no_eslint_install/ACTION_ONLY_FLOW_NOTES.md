# SrediST action-only flow

This version removes the visible report/prijava flow from the main UI and keeps the app centered around actions.

## What changed

- `/map` now shows only active action pins.
- Logged-in users can click the map to place a temporary yellow pin.
- The selected coordinates are written into the action form automatically.
- The action submit button is disabled until a map location is selected.
- `/events/new` uses the same map + temporary-pin action form.
- Newly created actions are saved as published events and become visible on the map.
- Completed, cancelled, and draft actions are hidden from the active map.
- The organizer or admin can now manage an action from its detail page:
  - mark it as completed
  - cancel it
  - reschedule it while active
- The dashboard and home page now talk about actions instead of reports/prijave.

## Manual test checklist

1. Log in as a normal user.
2. Open `/map`.
3. Click an empty place on the map.
4. Confirm a temporary yellow pin appears.
5. Confirm the latitude and longitude fields in the action form are filled.
6. Fill title, description, category, location description, and date/time.
7. Click `Unesi akciju`.
8. Confirm you are redirected to the new action detail page.
9. Open `/map` again and confirm the new action appears as a yellow pin.
10. Open the action detail page as the organizer.
11. Click `Zaključi kao završeno`.
12. Confirm the action status becomes completed.
13. Open `/map` again and confirm the completed action is no longer shown as an active map pin.
